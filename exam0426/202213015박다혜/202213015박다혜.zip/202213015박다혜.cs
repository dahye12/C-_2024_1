﻿/* internal class Program
{
   private static void Main(string[] args)
 {

       Console.WriteLine("라인 수 입력 : ");
       int num = int.Parse(Console.ReadLine());

      for (int i =0;i <num;i++)
       { 
           for (int j = 0; j > num + i; j++)
               Console.Write(' ');

   for (int j = 0; j < i + 1; j++)

           Console.Write( '★');
           Console.Write('\n');



       }
   }
}
*/
/*internal class Program
{
  private static void Main(string[] args)
{
       Console.WriteLine("숫자를 입력해주세요 : ");
       int num = int.Parse(Console.ReadLine());

       if ( num  )

   }
  }

*/
                                                                                                                     
internal class Program
{
    private static void Main(string[] args)
    {
        Console.WriteLine("1부터 100사이의 수 입력  : ");
        int num = int.Parse(Console.ReadLine());

      



    }
}
  

